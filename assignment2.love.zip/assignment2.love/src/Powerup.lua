Powerup = Class {} 

function Powerup:init()
    -- simple positional and dimensional variables

    self.x = math.random (0, VIRTUAL_WIDTH)
    self.y = -16

    self.dy = 0

    self.width = 16
    self.height = 16

    self.powernum = 1
end

function Powerup:reset()
    self.x = math.random (0, VIRTUAL_WIDTH)
    self.y = -16

    self.dy = 0

    self.width = 16
    self.height = 16

end

function Powerup:update(dt)
    self.dy = self.dy + 0.15 * dt
    self.y = self.y + self.dy 
end

function Powerup:collides(target)
    -- than the right edge of the other
    if self.x > target.x + target.width or target.x > self.x + self.width then
        return false
    end

    -- then check to see if the bottom edge of either is higher than the top
    -- edge of the other
    if self.y > target.y + target.height or target.y > self.y + self.height then
        return false
    end 

    -- if the above aren't true, they're overlapping
    return true
end 

function Powerup:render()
    love.graphics.draw(gTextures['main'], gFrames['powerup'][self.powernum],self.x, self.y)

end


