--[[
    GD50
    Pokemon

    Author: Colton Ogden
    cogden@cs50.harvard.edu
]]

Opponent = Class{}

function Opponent:init(def)
    self.party = def.party
end

function Opponent:takeTurn()

end