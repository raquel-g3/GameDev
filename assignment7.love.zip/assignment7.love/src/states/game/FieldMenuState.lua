--[[
    GD50
    Pokemon

    Author: Colton Ogden
    cogden@cs50.harvard.edu
]]

FieldMenuState = Class{__includes = BaseState}

function FieldMenuState:init()
    
end

function FieldMenuState:update(dt)

end

function FieldMenuState:render()

end