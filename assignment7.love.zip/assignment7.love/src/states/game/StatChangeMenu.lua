StatChangeMenu = Class{__includes = BaseState}

function StatChangeMenu:init(statsState, onClose)
    self.statsState = statsState
    self.oldHP = statsState[1]
    self.HPIncrease = statsState[5]
    self.oldAttack = statsState[2]
    self.attackIncrease = statsState[6]
    self.oldDefense = statsState[3]
    self.defenseIncrease = statsState[7]
    self.oldSpeed = statsState[4]
    self.speedIncrease = statsState[8]


     -- function to be called once this message is popped
    self.onClose = onClose or function() end
    
    self.statsMenu = Menu {
        x = VIRTUAL_WIDTH - 150,
        y = VIRTUAL_HEIGHT - 150,
        width = 150,
        height = 150,
        cursor = false,
        items = {
            {
                text = 'STATS',
                onSelect = function()
                    gStateStack:pop()
                end
            },
            {
                text = 'HP = (' .. tostring(self.oldHP) .. '+' .. tostring(self.HPIncrease) .. '=' .. self.oldHP + self.HPIncrease .. ')',
                onSelect = function()
                    gStateStack:pop()
                end
            },
            {
                text = 'Att = (' .. tostring(self.oldAttack) .. '+' .. tostring(self.attackIncrease) .. '=' .. self.oldAttack + self.attackIncrease .. ')',
                onSelect = function()
                    gStateStack:pop()
                end
            },
            {
                text = 'Def = (' .. tostring(self.oldDefense) .. '+' .. tostring(self.defenseIncrease) .. '=' .. self.oldDefense + self.defenseIncrease .. ')',
                onSelect = function()
                    gStateStack:pop()
                end
            },
            {
                text = 'Spd = (' .. tostring(self.oldSpeed) .. '+' .. tostring(self.speedIncrease) .. '=' .. self.oldSpeed + self.speedIncrease .. ')',
                onSelect = function()
                    gStateStack:pop()
                end
            }
        }
    }
end

function StatChangeMenu:update(dt)
    self.statsMenu:update(dt)
end

function StatChangeMenu:render()
    self.statsMenu:render()
end