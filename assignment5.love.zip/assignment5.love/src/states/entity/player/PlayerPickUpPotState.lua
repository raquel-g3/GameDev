PlayerPickUpPotState = Class{__includes = EntityWalkState}

function PlayerPickUpPotState:init(player, dungeon)
    self.player = player
    self.dungeon = dungeon

    -- render offset for spaced character sprite
    self.player.offsetY = 5
    self.player.offsetX = 8

    -- get reference to direction to play correct animation
    local direction = self.player.direction


    if direction == 'left' then
        self.player:changeAnimation('pick-left')
    elseif direction == 'right' then
        self.player:changeAnimation('pick-right')
    elseif direction == 'up' then
        self.player:changeAnimation('pick-up')
    else
        self.player:changeAnimation('pick-down')
    end
end

function PlayerPickUpPotState:update(dt)

    if love.keyboard.wasPressed('return') then
        --variable to know when to throw pot 

        --The player should only be able to pick up items if he is currently empty-handed 
        if self.entity.potState == false then 
            self.player:changeState('pickup-pot-walk')
        end 


    end
    
    if self.player.currentAnimation.timesPlayed > 0 then
        self.player.currentAnimation.timesPlayed = 0
        self.player:changeState('idle')
    end


end

function PlayerPickUpPotState:render()
local anim = self.player.currentAnimation
love.graphics.draw(gTextures[anim.texture], gFrames[anim.texture][anim:getCurrentFrame()],
    math.floor(self.player.x), math.floor(self.player.y - self.player.offsetY))

end