--[[
    GD50
    Match-3 Remake

    -- Tile Class --

    Author: Colton Ogden
    cogden@cs50.harvard.edu

    The individual tiles that make up our game board. Each Tile can have a
    color and a variety, with the varietes adding extra points to the matches.
]]

Tile = Class{}

function Tile:init(x, y, color, variety)
    
    -- board positions
    self.gridX = x
    self.gridY = y

    self.num = math.random(18)

    -- coordinate positions
    self.x = (self.gridX - 1) * 32
    self.y = (self.gridY - 1) * 32

    -- tile appearance/points
    self.color = color
    self.variety = variety

    --keeping track of shiny tiles in board
    self.shinytile = false 
    self.shinerEffect = false 

    --set timesr to turn shiner effect cursor on and off 
    Timer.every(0.3, function()
        self.shinerEffect= not self.shinerEffect
    end)
end

function Tile:render(x, y)

    -- draw shadow
    love.graphics.setColor(34, 32, 52,255)
    love.graphics.draw(gTextures['main'], gFrames['tiles'][self.color][self.variety],
        self.x + x + 2, self.y + y + 2)

    if self.num ~= 8 then 
        -- draw tile itself
            love.graphics.setColor(255, 255, 255, 220)
            love.graphics.draw(gTextures['main'], gFrames['tiles'][self.color][self.variety],
                self.x + x, self.y + y)
    else 
        -- multiply so drawing white rect makes it brighter
        --adding if/else statement so shine effect gives a 'glimering' effect that changes with timer 

        --drawing shine at different transparencies to give shine effect
        if self.shinerEffect then 
            love.graphics.setColor(255, 255, 255, 255)
        else 
            love.graphics.setColor(255,255,255,100)
        end 

        love.graphics.draw(gTextures['main'], gFrames['tiles'][self.color][self.variety],
            self.x + x, self.y + y)


        self.shinytile = true 
    end  
end
